"""
Telemetry Collection and 14-Column CSV Metrics Recorder
======================================================
Course: Bases de Datos en la Nube (IT2iD - 2026)
Reference: playbook.pdf (Section 8.2) & playbook_sesion.pdf (Slides 8-10)

Canonical CSV Header:
timestamp_epoch,engine,profile,query_id,concurrency,run_number,throughput_qps,latency_p50_ms,latency_p95_ms,latency_p99_ms,cpu_throttled_seconds,max_rss_mb,disk_spill,status
"""

import csv
import math
import os
from typing import Dict, Any, List, Optional
import numpy as np
import requests

CANONICAL_COLUMNS = [
    "timestamp_epoch",
    "engine",
    "profile",
    "query_id",
    "concurrency",
    "run_number",
    "throughput_qps",
    "latency_p50_ms",
    "latency_p95_ms",
    "latency_p99_ms",
    "cpu_throttled_seconds",
    "max_rss_mb",
    "disk_spill",
    "status"
]

VALID_STATUSES = {"ok", "spill", "oom", "error"}


class PrometheusCollector:
    """Scrapes container metrics from local Prometheus instance."""

    def __init__(self, prometheus_url: str = "http://localhost:9090"):
        self.url = prometheus_url.rstrip("/")

    def query_instant(self, query: str) -> Optional[float]:
        try:
            resp = requests.get(f"{self.url}/api/v1/query", params={"query": query}, timeout=3)
            resp.raise_for_status()
            data = resp.json()
            if data.get("status") == "success" and data["data"]["result"]:
                val = data["data"]["result"][0]["value"][1]
                return float(val)
        except Exception as e:
            details = getattr(getattr(e, "response", None), "text", "")
            print(f"Warning: Prometheus instant query failed ('{query}'): {e} {details}")
        return None

    def query_range_max(self, query: str, start_epoch: float, end_epoch: float) -> Optional[float]:
        try:
            resp = requests.get(
                f"{self.url}/api/v1/query_range",
                params={
                    "query": query,
                    "start": start_epoch,
                    "end": end_epoch,
                    "step": "1s"
                },
                timeout=5
            )
            resp.raise_for_status()
            data = resp.json()
            if data.get("status") == "success" and data["data"]["result"]:
                values = [
                    float(sample[1])
                    for series in data["data"]["result"]
                    for sample in series.get("values", [])
                    if math.isfinite(float(sample[1]))
                ]
                return max(values) if values else None
        except Exception as e:
            print(f"Warning: Prometheus range query failed ('{query}'): {e}")
        return None

    def _get_container_id(self, container_name: str) -> Optional[str]:
        try:
            import subprocess
            res = subprocess.run(
                ["docker", "inspect", "--format", "{{.Id}}", container_name],
                capture_output=True,
                text=True,
                check=True
            )
            return res.stdout.strip()
        except Exception:
            return None

    def get_container_throttled_seconds(
        self, container_name: str, start_epoch: float, end_epoch: float
    ) -> Optional[float]:
        """
        Calculate total CFS throttled seconds during the measurement window.
        """
        cid = self._get_container_id(container_name)
        if not cid or end_epoch <= start_epoch:
            return None
        selector = f'container_cpu_cfs_throttled_seconds_total{{id=~".*{cid}.*"}}'
        start_val = self.query_instant(f"sum({selector} @ {int(start_epoch)})")
        end_val = self.query_instant(f"sum({selector} @ {int(end_epoch)})")
        if start_val is None or end_val is None or end_val < start_val:
            return None
        return round(end_val - start_val, 4)

    def get_container_max_rss_mb(
        self, container_name: str, start_epoch: float, end_epoch: float
    ) -> Optional[float]:
        """
        Obtain peak RSS memory in Megabytes during the measurement window.
        """
        cid = self._get_container_id(container_name)
        if not cid or end_epoch <= start_epoch:
            return None
        query = f'max(container_memory_rss{{id=~".*{cid}.*"}})'
        max_bytes = self.query_range_max(query, start_epoch, end_epoch)
        return round(max_bytes / (1024 * 1024), 2) if max_bytes is not None else None


def calculate_latencies(latencies_ms: List[float]) -> Dict[str, Optional[float]]:
    """Calculate P50, P95, and P99 percentiles from latency array."""
    if not latencies_ms:
        return {"p50": None, "p95": None, "p99": None}
    
    arr = np.array(latencies_ms)
    return {
        "p50": round(float(np.percentile(arr, 50)), 2),
        "p95": round(float(np.percentile(arr, 95)), 2),
        "p99": round(float(np.percentile(arr, 99)), 2),
    }


def record_metrics_row(
    csv_path: str,
    timestamp_epoch: int,
    engine: str,
    profile: str,
    query_id: str,
    concurrency: int,
    run_number: int,
    throughput_qps: Optional[float],
    latency_p50_ms: Optional[float],
    latency_p95_ms: Optional[float],
    latency_p99_ms: Optional[float],
    cpu_throttled_seconds: Optional[float],
    max_rss_mb: Optional[float],
    disk_spill: Optional[bool],
    status: str
) -> None:
    """
    Append an immutable measurement row conforming verbatim to the 14-column contract.
    """
    if status not in VALID_STATUSES:
        raise ValueError(f"Invalid status '{status}'. Must be one of: {VALID_STATUSES}")

    row = {
        "timestamp_epoch": timestamp_epoch,
        "engine": engine,
        "profile": profile,
        "query_id": query_id,
        "concurrency": concurrency,
        "run_number": run_number,
        "throughput_qps": round(throughput_qps, 2) if throughput_qps is not None else "",
        "latency_p50_ms": round(latency_p50_ms, 2) if latency_p50_ms is not None else "",
        "latency_p95_ms": round(latency_p95_ms, 2) if latency_p95_ms is not None else "",
        "latency_p99_ms": round(latency_p99_ms, 2) if latency_p99_ms is not None else "",
        "cpu_throttled_seconds": round(cpu_throttled_seconds, 4) if cpu_throttled_seconds is not None else "",
        "max_rss_mb": round(max_rss_mb, 2) if max_rss_mb is not None else "",
        "disk_spill": disk_spill if disk_spill is not None else "",
        "status": status
    }

    file_exists = os.path.exists(csv_path) and os.path.getsize(csv_path) > 0
    os.makedirs(os.path.dirname(os.path.abspath(csv_path)), exist_ok=True)

    with open(csv_path, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=CANONICAL_COLUMNS)
        if not file_exists:
            writer.writeheader()
        writer.writerow(row)

    print(f"Recorded metric row in {csv_path}: {row}")

