"""
Benchmark Load Harness & Execution Orchestrator
===============================================
Course: Bases de Datos en la Nube (IT2iD - 2026)
Reference: playbook.pdf (Section 6, 7, 8) & playbook_sesion.pdf (Slide 8-13)

Supports:
- Concurrencies: 1, 10, 50 workers
- Lifecycle: Warmup -> Measurement -> Cooldown
- Canonical CSV metrics generation (14 columns)
"""

import argparse
import json
import multiprocessing as mp
import os
from queue import Empty
import time
from typing import List, Any, Dict

from benchmark_runner.metrics import (
    PrometheusCollector,
    calculate_latencies,
    record_metrics_row
)
from benchmark_runner.observe import (
    capture_mongodb_plan,
    capture_postgresql_plan,
    check_container_oom,
    save_container_diagnostic_log
)
from benchmark_runner.workers import (
    run_mongodb_worker,
    run_postgresql_worker
)
from benchmark_runner.status import classify_status


def format_optional(value: Any, decimals: int = 2) -> str:
    return "n/a" if value is None else f"{value:.{decimals}f}"


def load_query_file(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        if path.endswith(".json"):
            return json.load(f)
        return f.read().strip()


def main() -> None:
    parser = argparse.ArgumentParser(description="Multi-engine Contention Benchmark Runner")
    parser.add_argument("--engine", choices=["mongodb", "postgresql"], required=True)
    parser.add_argument("--profile", required=True, help="e.g. PROFILE_A_BASELINE, PROFILE_B_MEDIUM, PROFILE_C_SEVERE")
    parser.add_argument("--query", choices=["Q1", "Q2"], required=True)
    parser.add_argument("--concurrency", type=int, choices=[1, 10, 50], default=1)
    parser.add_argument("--run-number", type=int, default=1)
    parser.add_argument("--variant", type=str, default="default", help="e.g. allowDiskUse_false, work_mem_4MB")
    parser.add_argument("--warmup", type=float, default=60.0, help="Warmup duration in seconds")
    parser.add_argument("--duration", type=float, default=300.0, help="Measurement duration in seconds")
    parser.add_argument("--cooldown", type=float, default=60.0, help="Cooldown duration in seconds")
    parser.add_argument("--output-csv", type=str, default="results/metrics.csv")
    parser.add_argument("--prometheus-url", type=str, default="http://localhost:9090")
    parser.add_argument("--pg-port", type=int, default=5434, help="PostgreSQL Docker published port")

    args = parser.parse_args()

    container_name = f"benchmark_{args.engine}"
    print(f"\n{'='*70}")
    print(f"STARTING BENCHMARK CELL: {args.engine.upper()} | {args.profile} | {args.query} | Concurrency: {args.concurrency} | Run: {args.run_number} | Variant: {args.variant}")
    print(f"Warmup: {args.warmup}s | Measurement: {args.duration}s | Cooldown: {args.cooldown}s")
    print(f"{'='*70}\n")

    # Load query definition
    query_file = f"queries/{args.engine}/{args.query}.{'json' if args.engine == 'mongodb' else 'sql'}"
    query_data = load_query_file(query_file)

    # Resolve variant flags
    allow_disk_use = (args.variant == "allowDiskUse_true")
    work_mem = "64MB" if args.variant == "work_mem_64MB" else "4MB"

    # Capture the explain plan after measurement so it cannot warm the measured cache.
    artifact_namespace = os.path.splitext(os.path.basename(args.output_csv))[0]
    plan_out = f"results/plans/{artifact_namespace}_{args.engine}_{args.profile}_{args.query}_{args.variant}_run{args.run_number}.json"
    # Launch concurrency workers
    result_queue = mp.Queue()
    ready_queue = mp.Queue()
    error_event = mp.Event()
    start_event = mp.Event()
    workers: List[mp.Process] = []

    for i in range(args.concurrency):
        if args.engine == "mongodb":
            p = mp.Process(
                target=run_mongodb_worker,
                args=(i, query_data, allow_disk_use, args.warmup, args.duration,
                      result_queue, error_event, ready_queue, start_event)
            )
        else:
            p = mp.Process(
                target=run_postgresql_worker,
                args=(i, query_data, work_mem, args.warmup, args.duration,
                      result_queue, error_event, ready_queue, start_event, args.pg_port)
            )
        p.start()
        workers.append(p)

    # All workers must complete warmup before the common measurement window begins.
    ready_workers = set()
    ready_deadline = time.monotonic() + max(60.0, args.warmup + args.duration)
    while len(ready_workers) < args.concurrency and time.monotonic() < ready_deadline:
        try:
            ready_workers.add(ready_queue.get(timeout=0.5))
        except Empty:
            if error_event.is_set():
                break

    workers_ready = len(ready_workers) == args.concurrency and not error_event.is_set()
    if not workers_ready:
        print(f"Worker readiness failed: {len(ready_workers)}/{args.concurrency} workers ready")
        error_event.set()
    start_epoch = time.time()
    start_event.set()

    if workers_ready:
        measurement_deadline = time.monotonic() + args.duration
        while time.monotonic() < measurement_deadline:
            remaining = max(0.0, measurement_deadline - time.monotonic())
            print(
                f"\r[MEASUREMENT] {args.duration - remaining:.1f}s / {args.duration:.1f}s"
                f" | Active workers: {sum(1 for p in workers if p.is_alive())}",
                end="",
                flush=True,
            )
            time.sleep(min(1.0, remaining))
            if error_event.is_set():
                print("\nError event detected across workers. Aborting run early...")
                break
    end_epoch = time.time()

    print()
    forced_termination = False
    shutdown_deadline = time.monotonic() + max(30.0, args.duration)
    for p in workers:
        p.join(timeout=max(0.0, shutdown_deadline - time.monotonic()))
        if p.is_alive():
            p.terminate()
            forced_termination = True
            p.join(timeout=5)

    # Read exactly one result per worker; Queue.empty() is not reliable across processes.
    all_latencies: List[float] = []
    worker_results = {}
    for _ in range(args.concurrency):
        try:
            w_id, lats, err = result_queue.get(timeout=2)
        except Empty:
            break
        worker_results[w_id] = (lats, err)
        all_latencies.extend(lats)
    any_error = (
        error_event.is_set()
        or forced_termination
        or len(worker_results) != args.concurrency
        or any(p.exitcode != 0 for p in workers)
        or any(result[1] for result in worker_results.values())
        or any(not result[0] for result in worker_results.values())
    )

    # Cooldown phase
    if args.cooldown > 0:
        print(f"Entering cooldown phase ({args.cooldown}s)...")
        time.sleep(args.cooldown)

    disk_spill = None
    try:
        if args.engine == "mongodb":
            _, disk_spill = capture_mongodb_plan(
                mongo_uri="mongodb://localhost:27017",
                pipeline=query_data,
                output_path=plan_out,
                allow_disk_use=allow_disk_use,
            )
        else:
            _, disk_spill = capture_postgresql_plan(
                pg_host="localhost",
                pg_port=args.pg_port,
                pg_db="benchmark",
                pg_user="postgres",
                pg_pass="postgres",
                sql_query=query_data,
                output_path=plan_out.replace(".json", ".txt"),
                work_mem=work_mem,
            )
    except Exception as e:
        print(f"Plan capture failure: {e}")

    # Scrape Prometheus Telemetry
    prom = PrometheusCollector(args.prometheus_url)
    cpu_throttled = prom.get_container_throttled_seconds(container_name, start_epoch, end_epoch)
    max_rss = prom.get_container_max_rss_mb(container_name, start_epoch, end_epoch)

    # Check OOM status
    is_oom = check_container_oom(container_name)

    telemetry_complete = cpu_throttled is not None and max_rss is not None
    status = classify_status(
        oom_status=is_oom,
        worker_error=any_error,
        spill=disk_spill,
        telemetry_complete=telemetry_complete,
    )
    query_id = args.query if args.variant == "default" else f"{args.query}_{args.variant}"
    log_suffix = f"{artifact_namespace}_{args.engine}_{args.profile}_{query_id}_run{args.run_number}.log"

    if status == "oom":
        save_container_diagnostic_log(container_name, f"results/logs/oom_{log_suffix}")
    elif status in {"error", "spill"}:
        save_container_diagnostic_log(container_name, f"results/logs/{status}_{log_suffix}")

    # Compute metrics
    # Incomplete worker sets cannot produce valid latency/throughput statistics.
    lat_stats = calculate_latencies(all_latencies) if not any_error else {"p50": None, "p95": None, "p99": None}
    throughput = len(all_latencies) / args.duration if args.duration > 0 and not any_error else None

    # Record 14-column CSV
    record_metrics_row(
        csv_path=args.output_csv,
        timestamp_epoch=int(start_epoch),
        engine=args.engine,
        profile=args.profile,
        query_id=args.query if args.variant == "default" else f"{args.query}_{args.variant}",
        concurrency=args.concurrency,
        run_number=args.run_number,
        throughput_qps=throughput,
        latency_p50_ms=lat_stats["p50"],
        latency_p95_ms=lat_stats["p95"],
        latency_p99_ms=lat_stats["p99"],
        cpu_throttled_seconds=cpu_throttled,
        max_rss_mb=max_rss,
        disk_spill=disk_spill,
        status=status
    )

    print(
        f"\nCell complete. Summary: Throughput={format_optional(throughput)} QPS"
        f" | P95={format_optional(lat_stats['p95'])} ms | Status={status}"
    )


if __name__ == "__main__":
    main()
