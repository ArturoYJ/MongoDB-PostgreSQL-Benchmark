"""
Multiprocessing Worker Functions for Load Generation
===================================================
Defined in a separate top-level module to support macOS spawn unpickling.
"""

import multiprocessing as mp
import time
from typing import List
import psycopg2
import pymongo


def run_mongodb_worker(
    worker_id: int,
    pipeline: list,
    allow_disk_use: bool,
    warmup_sec: float,
    duration_sec: float,
    result_queue: mp.Queue,
    error_event: mp.Event,
    ready_queue: mp.Queue,
    start_event: mp.Event,
) -> None:
    client = None
    latencies: List[float] = []
    error_occurred = False
    try:
        client = pymongo.MongoClient("mongodb://localhost:27017", serverSelectionTimeoutMS=5000)
        client.admin.command("ping")
        coll = client["benchmark"]["orders"]

        warmup_end = time.monotonic() + warmup_sec
        while time.monotonic() < warmup_end and not error_event.is_set():
            coll.aggregate(pipeline, allowDiskUse=allow_disk_use).to_list(length=1000)

        if not error_event.is_set():
            ready_queue.put(worker_id)
            while not start_event.wait(0.1) and not error_event.is_set():
                pass

        measure_end = time.monotonic() + duration_sec
        while start_event.is_set() and time.monotonic() < measure_end and not error_event.is_set():
            t0 = time.monotonic()
            coll.aggregate(pipeline, allowDiskUse=allow_disk_use).to_list(length=1000)
            latencies.append((time.monotonic() - t0) * 1000.0)
    except Exception as e:
        error_occurred = True
        error_event.set()
        print(f"Worker {worker_id} caught MongoDB connection/query failure: {e}")
    finally:
        if client is not None:
            client.close()
        result_queue.put((worker_id, latencies, error_occurred))


def run_postgresql_worker(
    worker_id: int,
    sql_query: str,
    work_mem: str,
    warmup_sec: float,
    duration_sec: float,
    result_queue: mp.Queue,
    error_event: mp.Event,
    ready_queue: mp.Queue,
    start_event: mp.Event,
    pg_port: int = 5434,
) -> None:
    conn = None
    cursor = None
    latencies: List[float] = []
    error_occurred = False
    try:
        conn = psycopg2.connect(
            host="localhost",
            port=pg_port,
            dbname="benchmark",
            user="postgres",
            password="postgres",
            connect_timeout=5,
        )
        conn.autocommit = True
        cursor = conn.cursor()
        cursor.execute(f"SET work_mem = '{work_mem}';")

        warmup_end = time.monotonic() + warmup_sec
        while time.monotonic() < warmup_end and not error_event.is_set():
            cursor.execute(sql_query)
            cursor.fetchall()

        if not error_event.is_set():
            ready_queue.put(worker_id)
            while not start_event.wait(0.1) and not error_event.is_set():
                pass

        measure_end = time.monotonic() + duration_sec
        while start_event.is_set() and time.monotonic() < measure_end and not error_event.is_set():
            t0 = time.monotonic()
            cursor.execute(sql_query)
            cursor.fetchall()
            latencies.append((time.monotonic() - t0) * 1000.0)
    except Exception as e:
        error_occurred = True
        error_event.set()
        print(f"Worker {worker_id} caught PostgreSQL connection/query failure: {e}")
    finally:
        if cursor is not None:
            cursor.close()
        if conn is not None:
            conn.close()
        result_queue.put((worker_id, latencies, error_occurred))
