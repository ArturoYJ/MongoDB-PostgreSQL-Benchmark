"""
Plan Observation and Diagnostics Collector
==========================================
Course: Bases de Datos en la Nube (IT2iD - 2026)
Reference: playbook.pdf (Section 8.3 & Reviewer Question 6) & playbook_sesion.pdf (Slide 10-11)

Extracts execution plans:
- MongoDB: explain("executionStats")
- PostgreSQL: EXPLAIN (ANALYZE, BUFFERS)
Detects disk spill and captures OOM events.
"""

import json
import os
import re
import subprocess
from typing import Dict, Any, Optional, Tuple
import psycopg2
import pymongo


def capture_mongodb_plan(
    mongo_uri: str,
    pipeline: list,
    output_path: str,
    allow_disk_use: bool = False
) -> Tuple[Dict[str, Any], Optional[bool]]:
    """
    Execute MongoDB explain("executionStats") and detect if disk spill occurred.
    """
    client = pymongo.MongoClient(mongo_uri, serverSelectionTimeoutMS=5000)
    db = client["benchmark"]
    coll = db["orders"]

    # In pymongo, explain is invoked via command
    cmd = {
        "explain": {
            "aggregate": "orders",
            "pipeline": pipeline,
            "cursor": {},
            "allowDiskUse": allow_disk_use
        },
        "verbosity": "executionStats"
    }

    try:
        plan_result = db.command(cmd)
    finally:
        client.close()
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(plan_result, f, indent=2, default=str)

    disk_spill = detect_mongodb_spill(plan_result)
    print(f"Captured MongoDB execution plan to {output_path} (disk_spill={disk_spill})")
    return plan_result, disk_spill


def capture_postgresql_plan(
    pg_host: str,
    pg_port: int = 5434,
    pg_db: str = "benchmark",
    pg_user: str = "postgres",
    pg_pass: str = "postgres",
    sql_query: str = "",
    output_path: str = "",
    work_mem: str = "4MB"
) -> Tuple[str, bool]:
    """
    Execute PostgreSQL EXPLAIN (ANALYZE, BUFFERS) and detect external merge disk spill.
    """
    conn = psycopg2.connect(
        host=pg_host,
        port=pg_port,
        dbname=pg_db,
        user=pg_user,
        password=pg_pass
    )
    conn.autocommit = True
    cursor = conn.cursor()

    try:
        cursor.execute(f"SET work_mem = '{work_mem}';")
        cursor.execute(f"EXPLAIN (ANALYZE, BUFFERS) {sql_query}")
        plan_lines = [row[0] for row in cursor.fetchall()]
        plan_text = "\n".join(plan_lines)
    finally:
        cursor.close()
        conn.close()

    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(plan_text)

    disk_spill = detect_postgresql_spill(plan_text)
    print(f"Captured PostgreSQL execution plan to {output_path} (disk_spill={disk_spill})")
    return plan_text, disk_spill


def detect_mongodb_spill(plan: Any) -> Optional[bool]:
    """Return spill evidence from explicit MongoDB execution-stat values.

    Missing indicators are unknown rather than silently interpreted as no spill.
    """
    indicators = []
    spill_flags = {"usedDisk", "spilledToDisk"}
    spill_counters = {"spills", "spilledBytes", "spilledRecords", "spilledDataStorageSize"}

    def walk(value: Any) -> None:
        if isinstance(value, dict):
            for key, child in value.items():
                if key in spill_flags and isinstance(child, bool):
                    indicators.append(child)
                elif key in spill_counters and isinstance(child, (int, float)) and not isinstance(child, bool):
                    indicators.append(child > 0)
                walk(child)
        elif isinstance(value, list):
            for child in value:
                walk(child)

    walk(plan)
    if not indicators:
        return None
    return any(indicators)


def detect_postgresql_spill(plan_text: str) -> bool:
    """Detect PostgreSQL sort spills without treating shared-buffer writes as temp spill."""
    if re.search(r"\bSort Method:\s*external\b", plan_text, re.IGNORECASE):
        return True
    for segment in re.findall(r"\btemp\b([^\n]*)", plan_text, re.IGNORECASE):
        if any(int(value) > 0 for value in re.findall(r"\b(?:read|written)=(\d+)\b", segment, re.IGNORECASE)):
            return True
    return False


def check_container_oom(container_name: str) -> Optional[bool]:
    """
    Inspect container state to verify if kernel OOM killer terminated the engine.
    """
    try:
        cmd = [
            "docker", "inspect",
            "--format", "{{.State.OOMKilled}}",
            container_name
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        return result.stdout.strip().lower() == "true"
    except Exception as e:
        print(f"Warning: Could not inspect OOM state for {container_name}: {e}")
        return None


def save_container_diagnostic_log(container_name: str, log_path: str) -> None:
    """
    Dump container logs upon detecting spill or OOM failure.
    """
    try:
        os.makedirs(os.path.dirname(os.path.abspath(log_path)), exist_ok=True)
        cmd = ["docker", "logs", "--tail", "500", container_name]
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        with open(log_path, "w", encoding="utf-8") as f:
            f.write(result.stdout)
            if result.stderr:
                f.write("\n--- STDERR ---\n")
                f.write(result.stderr)
        print(f"Saved diagnostic log for {container_name} to {log_path}")
    except Exception as e:
        print(f"Warning: Failed to save diagnostic log: {e}")
