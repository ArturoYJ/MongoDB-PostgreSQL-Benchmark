#!/usr/bin/env bash
# ==============================================================================
# Matrix Orchestrator for Database Contention Benchmark
# Course: Bases de Datos en la Nube (IT2iD - 2026)
# Reference: playbook.pdf (Section 6, 8.1) & playbook_sesion.pdf (Slide 8, 13)
# ==============================================================================

set -euo pipefail

WORKSPACE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$WORKSPACE_ROOT"

RUN_LOCK_DIR="$WORKSPACE_ROOT/.benchmark-run.lock"
if ! mkdir "$RUN_LOCK_DIR" 2>/dev/null; then
    echo "Another benchmark/preflight invocation may be active (or a stale lock exists at $RUN_LOCK_DIR). Refusing concurrent execution." >&2
    exit 1
fi

cleanup_database_containers() {
    docker compose stop mongodb postgresql >/dev/null 2>&1 || true
    rmdir "$RUN_LOCK_DIR" 2>/dev/null || true
}
trap cleanup_database_containers EXIT

PYTHON_BIN="$WORKSPACE_ROOT/.venv/bin/python3"
if [ ! -f "$PYTHON_BIN" ]; then
    PYTHON_BIN="python3"
fi

CSV_OUTPUT="results/metrics.csv"
PILOT_CSV_OUTPUT="results/pilot_metrics.csv"
PROMETHEUS_URL="http://127.0.0.1:9090"

# Colors for terminal clarity
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}[INFO]${NC} $(date +'%Y-%m-%dT%H:%M:%S%z') $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $(date +'%Y-%m-%dT%H:%M:%S%z') $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $(date +'%Y-%m-%dT%H:%M:%S%z') $1"
}

# ------------------------------------------------------------------------------
# 1. Telemetry Stack Verification
# ------------------------------------------------------------------------------
ensure_telemetry_stack() {
    log_info "Ensuring Prometheus, cAdvisor, and Node Exporter are active..."
    docker compose up -d cadvisor node-exporter prometheus
    sleep 3
}

run_preflight() {
    local engines=("mongodb" "postgresql")
    log_info "Running read-only preflight against both databases, one engine at a time..."
    for engine in "${engines[@]}"; do
        switch_engine "$engine" "PROFILE_A_BASELINE"
        "$PYTHON_BIN" -m benchmark_runner.preflight \
            --engine "$engine" \
            --csv "$CSV_OUTPUT" \
            --prometheus-url "$PROMETHEUS_URL"
    done
    log_success "Preflight passed for both database engines and telemetry."
}

# ------------------------------------------------------------------------------
# 2. Linux VM Kernel Page Cache Flush (Bridge Mechanism)
# ------------------------------------------------------------------------------
flush_page_cache() {
    log_info "Flushing Linux VM page cache via privileged container..."
    docker run --rm --privileged alpine:3.22 sh -c "sync && echo 3 > /proc/sys/vm/drop_caches"
    sleep 2
}

# ------------------------------------------------------------------------------
# 3. Database Engine Lifecycle & Isolation
# ------------------------------------------------------------------------------
switch_engine() {
    local target_engine="$1"
    local profile="$2"

    local cpus="4.0"
    local memory="4096m"

    case "$profile" in
        "PROFILE_A_BASELINE")
            cpus="4.0"
            memory="4096m"
            ;;
        "PROFILE_B_MEDIUM")
            cpus="2.0"
            memory="2048m"
            ;;
        "PROFILE_C_SEVERE")
            cpus="1.0"
            memory="1024m"
            ;;
        *)
            log_warn "Unknown profile '$profile', defaulting to PROFILE_A_BASELINE"
            ;;
    esac

    # Strictly enforce Single-Engine Isolation (preferences.md)
    if [ "$target_engine" == "mongodb" ]; then
        log_info "Stopping PostgreSQL to enforce single-engine isolation..."
        docker compose stop postgresql 2>/dev/null || true
        log_info "Launching MongoDB under $profile (CPUs: $cpus, RAM: $memory, Swap: 0)..."
        BENCHMARK_CPUS="$cpus" BENCHMARK_MEMORY="$memory" docker compose up -d mongodb
    elif [ "$target_engine" == "postgresql" ]; then
        log_info "Stopping MongoDB to enforce single-engine isolation..."
        docker compose stop mongodb 2>/dev/null || true
        log_info "Launching PostgreSQL under $profile (CPUs: $cpus, RAM: $memory, Swap: 0)..."
        BENCHMARK_CPUS="$cpus" BENCHMARK_MEMORY="$memory" docker compose up -d postgresql
    fi

    wait_for_engine_ready "$target_engine"
}

wait_for_engine_ready() {
    local engine="$1"
    local container="benchmark_${engine}"
    local attempt
    log_info "Waiting for $engine readiness (up to 60 seconds)..."
    for attempt in {1..60}; do
        if [ "$engine" == "mongodb" ]; then
            if docker exec "$container" mongosh --quiet --eval 'db.adminCommand({ping: 1}).ok' >/dev/null 2>&1; then
                return 0
            fi
        elif [ "$engine" == "postgresql" ]; then
            if docker exec "$container" pg_isready -q -U postgres -d benchmark >/dev/null 2>&1; then
                return 0
            fi
        fi
        sleep 1
    done
    log_warn "$engine did not become ready within 60 seconds. Recent container logs:"
    docker logs --tail 80 "$container" >&2 || true
    return 1
}

ensure_engine_running() {
    local engine="$1"
    local profile="$2"
    local container="benchmark_${engine}"

    if ! docker ps --format '{{.Names}}' | grep -q "^${container}$"; then
        log_warn "Container ${container} is down (possibly OOM-killed). Recovering under ${profile}..."
        switch_engine "$engine" "$profile"
    fi
}

is_run_completed() {
    local engine="$1"
    local profile="$2"
    local query_id="$3"
    local concurrency="$4"
    local run_number="$5"

    if [ ! -f "$CSV_OUTPUT" ]; then
        return 1
    fi

    if grep -q "^[0-9]*,${engine},${profile},${query_id},${concurrency},${run_number}," "$CSV_OUTPUT" 2>/dev/null; then
        return 0
    fi
    return 1
}

# ------------------------------------------------------------------------------
# 4. Pilot Single-Cell Validation Run (Slide 13)
# ------------------------------------------------------------------------------
run_pilot() {
    log_info "=== EXECUTING PILOTS: Q1 + BOTH Q2 VARIANTS ON BOTH ENGINES ==="
    if [ -e "$PILOT_CSV_OUTPUT" ]; then
        echo "Pilot output already exists at $PILOT_CSV_OUTPUT; archive it or choose another path before rerunning."
        exit 1
    fi
    ensure_telemetry_stack
    run_preflight

    local engines=("mongodb" "postgresql")
    for engine in "${engines[@]}"; do
        switch_engine "$engine" "PROFILE_A_BASELINE"
        for query in "Q1" "Q2"; do
            local variants=("default")
            if [ "$query" == "Q2" ]; then
                if [ "$engine" == "mongodb" ]; then
                    variants=("allowDiskUse_false" "allowDiskUse_true")
                else
                    variants=("work_mem_4MB" "work_mem_64MB")
                fi
            fi
            for variant in "${variants[@]}"; do
                ensure_engine_running "$engine" "PROFILE_A_BASELINE"
                flush_page_cache
                log_info "Pilot: $engine | PROFILE_A_BASELINE | $query | C=1 | variant=$variant"
                "$PYTHON_BIN" -m benchmark_runner \
                    --engine "$engine" \
                    --profile "PROFILE_A_BASELINE" \
                    --query "$query" \
                    --concurrency 1 \
                    --run-number 1 \
                    --variant "$variant" \
                    --warmup 5 \
                    --duration 15 \
                    --cooldown 3 \
                    --output-csv "$PILOT_CSV_OUTPUT" \
                    --prometheus-url "$PROMETHEUS_URL"
            done
        done
    done

    docker compose stop mongodb postgresql
    log_success "Six pilot rows recorded in $PILOT_CSV_OUTPUT."
}

# ------------------------------------------------------------------------------
# 5. Full Matrix Execution
# ------------------------------------------------------------------------------
run_full_matrix() {
    log_info "=== INITIATING FULL BENCHMARK MATRIX (162 RUNS) ==="
    ensure_telemetry_stack
    run_preflight

    local engines=("mongodb" "postgresql")
    local profiles=("PROFILE_A_BASELINE" "PROFILE_B_MEDIUM" "PROFILE_C_SEVERE")
    local concurrencies=(1 10 50)
    local warmup=60
    local duration=300
    local cooldown=60

    for engine in "${engines[@]}"; do
        for profile in "${profiles[@]}"; do
            switch_engine "$engine" "$profile"

            # Execute Q1 (3 concurrencies x 3 runs = 9 runs)
            for concurrency in "${concurrencies[@]}"; do
                for run_num in 1 2 3; do
                    if is_run_completed "$engine" "$profile" "Q1" "$concurrency" "$run_num"; then
                        log_info "Run already present in CSV: $engine | $profile | Q1 | C=$concurrency | Run=$run_num. Skipping..."
                        continue
                    fi

                    ensure_engine_running "$engine" "$profile"
                    flush_page_cache
                    "$PYTHON_BIN" -m benchmark_runner \
                        --engine "$engine" \
                        --profile "$profile" \
                        --query "Q1" \
                        --concurrency "$concurrency" \
                        --run-number "$run_num" \
                        --variant "default" \
                        --warmup "$warmup" \
                        --duration "$duration" \
                        --cooldown "$cooldown" \
                        --output-csv "$CSV_OUTPUT"
                done
            done

            # Execute Q2 Memory Stress Variants (2 variants x 3 concurrencies x 3 runs = 18 runs)
            local variants=()
            if [ "$engine" == "mongodb" ]; then
                variants=("allowDiskUse_false" "allowDiskUse_true")
            else
                variants=("work_mem_4MB" "work_mem_64MB")
            fi

            for variant in "${variants[@]}"; do
                local q_key="Q2_${variant}"
                for concurrency in "${concurrencies[@]}"; do
                    for run_num in 1 2 3; do
                        if is_run_completed "$engine" "$profile" "$q_key" "$concurrency" "$run_num"; then
                            log_info "Run already present in CSV: $engine | $profile | $q_key | C=$concurrency | Run=$run_num. Skipping..."
                            continue
                        fi

                        ensure_engine_running "$engine" "$profile"
                        flush_page_cache
                        "$PYTHON_BIN" -m benchmark_runner \
                            --engine "$engine" \
                            --profile "$profile" \
                            --query "Q2" \
                            --concurrency "$concurrency" \
                            --run-number "$run_num" \
                            --variant "$variant" \
                            --warmup "$warmup" \
                            --duration "$duration" \
                            --cooldown "$cooldown" \
                            --output-csv "$CSV_OUTPUT"
                    done
                done
            done

        done
    done

    log_success "All 162 runs of the benchmark matrix completed successfully."
    docker compose stop mongodb postgresql
}

# ------------------------------------------------------------------------------
# Entrypoint Dispatcher
# ------------------------------------------------------------------------------
main() {
    local mode="${1:---pilot}"
    case "$mode" in
        --pilot)
            run_pilot
            ;;
        --full)
            run_full_matrix
            ;;
        --preflight)
            ensure_telemetry_stack
            run_preflight
            docker compose stop mongodb postgresql
            ;;
        *)
            echo "Usage: $0 [--preflight | --pilot | --full]"
            exit 1
            ;;
    esac
}

main "$@"
