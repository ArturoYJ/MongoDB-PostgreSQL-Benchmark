import unittest
import csv
import os
import tempfile
from unittest.mock import patch

from benchmark_runner.metrics import CANONICAL_COLUMNS, PrometheusCollector, calculate_latencies, record_metrics_row
from benchmark_runner.__main__ import format_optional
from benchmark_runner.observe import detect_mongodb_spill, detect_postgresql_spill
from benchmark_runner.preflight import canonical_document_digest
from benchmark_runner.status import classify_status


class SpillClassificationTests(unittest.TestCase):
    def test_mongodb_used_disk_false_is_not_spill(self):
        self.assertFalse(detect_mongodb_spill({"stages": [{"$sort": {"usedDisk": False}}]}))

    def test_mongodb_used_disk_true_is_spill(self):
        self.assertTrue(detect_mongodb_spill({"stages": [{"$sort": {"usedDisk": True}}]}))

    def test_mongodb_positive_spill_counter_is_spill(self):
        self.assertTrue(detect_mongodb_spill({"executionStats": {"spills": 2}}))

    def test_postgresql_zero_written_pages_are_not_spill(self):
        self.assertFalse(detect_postgresql_spill("Buffers: shared hit=10 written=0"))

    def test_postgresql_temp_pages_are_spill(self):
        self.assertTrue(detect_postgresql_spill("Buffers: temp read=0 written=3"))

    def test_postgresql_external_merge_is_spill(self):
        self.assertTrue(detect_postgresql_spill("Sort Method: external merge  Disk: 2048kB"))

    def test_postgresql_shared_buffer_write_is_not_spill(self):
        self.assertFalse(detect_postgresql_spill("Buffers: shared hit=2 written=4"))


class StatusClassificationTests(unittest.TestCase):
    def test_missing_telemetry_is_error_not_zero_success(self):
        self.assertEqual(
            classify_status(oom_status=False, worker_error=False, spill=False, telemetry_complete=False),
            "error",
        )

    def test_missing_spill_evidence_is_error(self):
        self.assertEqual(
            classify_status(oom_status=False, worker_error=False, spill=None, telemetry_complete=True),
            "error",
        )

    def test_oom_has_priority(self):
        self.assertEqual(
            classify_status(oom_status=True, worker_error=True, spill=None, telemetry_complete=False),
            "oom",
        )

    def test_worker_error_is_not_ok(self):
        self.assertEqual(
            classify_status(oom_status=False, worker_error=True, spill=False, telemetry_complete=True),
            "error",
        )

    def test_spill_and_ok_classification(self):
        self.assertEqual(
            classify_status(oom_status=False, worker_error=False, spill=True, telemetry_complete=True),
            "spill",
        )
        self.assertEqual(
            classify_status(oom_status=False, worker_error=False, spill=False, telemetry_complete=True),
            "ok",
        )


class MissingTelemetryTests(unittest.TestCase):
    def test_optional_summary_values_format_without_crashing(self):
        self.assertEqual(format_optional(None), "n/a")
        self.assertEqual(format_optional(1.25), "1.25")

    def test_document_fingerprint_ignores_key_order_but_not_values(self):
        first = {"order_id": "x", "payment": {"total": 12.0}}
        reordered = {"payment": {"total": 12.0}, "order_id": "x"}
        changed = {"order_id": "x", "payment": {"total": 13.0}}
        self.assertEqual(canonical_document_digest(first), canonical_document_digest(reordered))
        self.assertNotEqual(canonical_document_digest(first), canonical_document_digest(changed))

    def test_missing_throttle_samples_return_none_not_zero(self):
        collector = PrometheusCollector()
        with patch.object(collector, "_get_container_id", return_value="abc123"):
            with patch.object(collector, "query_instant", return_value=None):
                self.assertIsNone(collector.get_container_throttled_seconds("db", 1, 10))

    def test_throttle_counter_uses_valid_selector_timestamp_syntax(self):
        collector = PrometheusCollector()
        with patch.object(collector, "_get_container_id", return_value="abc123"):
            with patch.object(collector, "query_instant", side_effect=[2.0, 3.5]) as query:
                self.assertEqual(collector.get_container_throttled_seconds("db", 100, 200), 1.5)
                self.assertIn('sum(container_cpu_cfs_throttled_seconds_total{id=~".*abc123.*"} @ 100)', query.call_args_list[0].args[0])
                self.assertIn('sum(container_cpu_cfs_throttled_seconds_total{id=~".*abc123.*"} @ 200)', query.call_args_list[1].args[0])

    def test_missing_rss_samples_return_none_not_zero(self):
        collector = PrometheusCollector()
        with patch.object(collector, "_get_container_id", return_value="abc123"):
            with patch.object(collector, "query_range_max", return_value=None):
                self.assertIsNone(collector.get_container_max_rss_mb("db", 1, 10))

    def test_empty_latency_samples_are_unknown_not_zero(self):
        self.assertEqual(calculate_latencies([]), {"p50": None, "p95": None, "p99": None})

    def test_csv_preserves_empty_values_without_changing_schema(self):
        with tempfile.TemporaryDirectory() as directory:
            output = os.path.join(directory, "metrics.csv")
            record_metrics_row(
                csv_path=output,
                timestamp_epoch=1,
                engine="mongodb",
                profile="PROFILE_A_BASELINE",
                query_id="Q1",
                concurrency=1,
                run_number=1,
                throughput_qps=None,
                latency_p50_ms=None,
                latency_p95_ms=None,
                latency_p99_ms=None,
                cpu_throttled_seconds=None,
                max_rss_mb=None,
                disk_spill=None,
                status="error",
            )
            with open(output, newline="", encoding="utf-8") as source:
                rows = list(csv.DictReader(source))
            self.assertEqual(list(rows[0]), CANONICAL_COLUMNS)
            self.assertEqual(rows[0]["status"], "error")
            self.assertEqual(rows[0]["cpu_throttled_seconds"], "")
            self.assertEqual(rows[0]["disk_spill"], "")


if __name__ == "__main__":
    unittest.main()
